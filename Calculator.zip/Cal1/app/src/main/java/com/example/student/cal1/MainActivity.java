package com.example.student.cal1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    Button add, sub, mul, div;
    Button zero, one, two, three, four, five, six, seven, eight, nine;
    Button decimal, clear, equal, del;
    TextView screen, equation, numbers;
    float num1, num2, result;
    boolean oAdd, oSub, oMul, oDiv;

    int ad=0, sb=0, ml=0, dv=0, deci=0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add = (Button) findViewById(R.id.add);
        sub = (Button) findViewById(R.id.sub);
        mul = (Button) findViewById(R.id.mul);
        div = (Button) findViewById(R.id.div);

        zero = (Button) findViewById(R.id.zero);
        one = (Button) findViewById(R.id.one);
        two = (Button) findViewById(R.id.two);
        three = (Button) findViewById(R.id.three);
        four = (Button) findViewById(R.id.four);
        five = (Button) findViewById(R.id.five);
        six = (Button) findViewById(R.id.six);
        seven = (Button) findViewById(R.id.seven);
        eight = (Button) findViewById(R.id.eight);
        nine = (Button) findViewById(R.id.nine);

        decimal = (Button) findViewById(R.id.decimal);
        clear = (Button) findViewById(R.id.clear);
        equal = (Button) findViewById(R.id.equal);
        del = (Button) findViewById(R.id.del);

        screen = (TextView) findViewById(R.id.screen);
        equation = (TextView) findViewById(R.id.equation);
        numbers = (TextView) findViewById(R.id.numbers);



        zero.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
               numbers.setText(numbers.getText() + "0");
               equation.setText(equation.getText() + "0");
               // screen.setText(screen.getText().toString() + "0");
            }
        });

        one.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                numbers.setText(numbers.getText() + "1");
                equation.setText(equation.getText() + "1");
            }
        });

        two.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                numbers.setText(numbers.getText() + "2");
                equation.setText(equation.getText() + "2");
            }
        });

        three.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                numbers.setText(numbers.getText() + "3");
                equation.setText(equation.getText() + "3");
            }
        });

        four.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                numbers.setText(numbers.getText() + "4");
                equation.setText(equation.getText() + "4");
            }
        });

        five.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                numbers.setText(numbers.getText() + "5");
                equation.setText(equation.getText() + "5");
            }
        });

        six.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                numbers.setText(numbers.getText() + "6");
                equation.setText(equation.getText() + "6");
            }
        });

        seven.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                numbers.setText(numbers.getText() + "7");
                equation.setText(equation.getText() + "7");
            }
        });

        eight.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                numbers.setText(numbers.getText() + "8");
                equation.setText(equation.getText() + "8");
            }
        });

        nine.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                numbers.setText(numbers.getText() + "9");
                equation.setText(equation.getText() + "9");
            }
        });

        decimal.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(deci == 0)
                {
                    deci = 1;
                    numbers.setText(numbers.getText() + ".");
                    equation.setText(equation.getText() + ".");
                }
            }
        });

        clear.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                deci=0;
                screen.setText("");
                equation.setText("");
                numbers.setText("");
                num1=0;
                num2=0;
            }
        });

        /*

        DONE TILL HERE

         */

        add.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (numbers.getText() == "")
                {
                    equation.setText(equation.getText() + "+");
                    oAdd = true;
                }
                else if(num1 != 0)
                {
                    oAdd = true;  //in others make it false
                    deci=0;
                    num2 = Float.parseFloat(numbers.getText()+"");
                    equation.setText(equation.getText() + "+");
                    screen.setText(num1 + num2 + "");
                    numbers.setText("");
                    num1=num1+num2;
                }
                else
                {
                    deci = 0;
                    num1 = Float.parseFloat(numbers.getText() + "");
                    oAdd = true;
                    numbers.setText("");
                    equation.setText(equation.getText() + "" + numbers.getText() + "+");
                    screen.setText(null);
                }
            }
        });

        sub.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (numbers.getText() == "")
                {
                    equation.setText(equation.getText() + "-");
                    oSub = true;
                }
                else if(num1 != 0)
                {
                    oSub = true;  //in others make it false
                    deci=0;
                    num2 = Float.parseFloat(numbers.getText()+"");
                    equation.setText(equation.getText() + "-");
                    screen.setText(num1 - num2 + "");
                    numbers.setText("");
                    num1=num1-num2;
                }
                else
                {
                    deci = 0;
                    num1 = Float.parseFloat(numbers.getText() + "");
                    oSub = true;
                    numbers.setText("");
                    equation.setText(equation.getText() + "" + numbers.getText() + "-");
                    screen.setText(null);
                }
            }
        });

        mul.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (equation.getText() == "" && num1 == 0)
                {
                    equation.setText("*");
                    screen.setText("ERROR");
                }
                else if(num1 != 0)
                {
                    oMul = true;  //in others make it false
                    deci=0;
                    num2 = Float.parseFloat(numbers.getText()+"");
                    equation.setText(equation.getText() + "*");
                    screen.setText(num1 * num2 + "");
                    numbers.setText("");
                    num1=num1*num2;
                }
                else
                {
                    deci = 0;
                    num1 = Float.parseFloat(numbers.getText() + "");
                    oMul = true;
                    numbers.setText("");
                    equation.setText(equation.getText() + "" + numbers.getText() + "*");
                    screen.setText(null);
                }
            }
        });

        div.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (equation.getText() == "" && num1 == 0)
                {
                    equation.setText("/");
                    screen.setText("ERROR");
                }
                else if(num1 != 0)
                {
                    oDiv = true;  //in others make it false
                    deci=0;
                    num2 = Float.parseFloat(numbers.getText()+"");
                    equation.setText(equation.getText() + "/");
                    screen.setText(num1 / num2 + "");
                    numbers.setText("");
                    num1=num1/num2;
                }
                else
                {
                    deci = 0;
                    num1 = Float.parseFloat(numbers.getText() + "");
                    oDiv = true;
                    numbers.setText("");
                    equation.setText(equation.getText() + "" + numbers.getText() + "/");
                    screen.setText(null);
                }
            }
        });

        equal.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                deci=0;
                num2 = Float.parseFloat(numbers.getText()+"");

                numbers.setText("");
                if (oAdd == true)
                {
                    screen.setText(num1 + num2 + "");
                    num1=num1+num2;
                    oAdd = false;
                }

                if (oSub == true)
                {
                    screen.setText(num1 - num2 + "");
                    num1=num1-num2;
                    oSub = false;
                }

                if (oMul == true)
                {
                    screen.setText(num1 * num2 + "");
                    num1=num1*num2;
                    oMul = false;
                }

                if (oDiv == true)
                {
                    if (num2 == 0)
                    {
                        screen.setText("NaN");
                    }
                    else
                    {
                        screen.setText(num1 / num2 + "");
                        num1=num1/num2;
                    }
                    oDiv = false;
                }
                num1 = Float.parseFloat(screen.getText()+"");

            }
        });

        del.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String str = numbers.getText().toString();
                if (str.length() > 1)
                {
                    str = str.substring(0, str.length() - 1);
                    numbers.setText(str);
                    equation.setText(str);
                }
                else if (str.length() <= 1)
                {
                    numbers.setText("");
                    equation.setText(str);
                }
            }
        });
    }
}